%% Parameters.
for jj = 5
thetaoffset = jj*0.05;
thetastep = 1/2*250;
theta = 0+thetaoffset:thetastep:pi/2-thetaoffset;
theta = cat(1,theta,theta+pi/2,theta+pi,theta+3*pi/2);

%% Programme.
for rr = 512:-1:1
    for ii = length(theta):-1:1
        tt(ii) = afint(round(512+rr*cos(theta(ii))),round(512+rr*sin(theta(ii))));
    end
    afintLine(rr) = sum(tt)/length(theta);
end

whos afintLine
x = 1:length(afintLine);
figure
plot(x,afintLine)
end